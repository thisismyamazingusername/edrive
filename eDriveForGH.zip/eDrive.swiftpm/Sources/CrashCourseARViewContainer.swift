
import SwiftUI
import RealityKit
import ARKit
import AVFoundation
import Combine

struct CrashCourseARViewContainer: UIViewRepresentable {
    
    func makeUIView(context: Context) -> ARView {
        let arView = ARView(frame: .zero)
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        arView.session.run(config)
        
        if let scene = try? Entity.load(named: "main") {
            let anchor = AnchorEntity(plane: .horizontal)
            anchor.addChild(scene)
            arView.scene.addAnchor(anchor)
        }
                
        context.coordinator.arView = arView
        return arView
    }
    
    func updateUIView(_ uiView: ARView, context: Context) {}
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject {
        var parent: CrashCourseARViewContainer
        weak var arView: ARView?
        private var cancellables: Set<AnyCancellable> = []
        
        init(_ parent: CrashCourseARViewContainer) {
            self.parent = parent
            super.init()
        }
        
    }
}
