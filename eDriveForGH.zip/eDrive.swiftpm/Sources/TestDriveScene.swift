//
//  TestDriveScene.swift
//  eDrive Playground
//
//  Created by sd on 2/23/25.
//

import SwiftUI
import SceneKit
import RealityKit
import ARKit
import ModelIO


extension SCNVector3 {
    func distance(to vector: SCNVector3) -> Float {
        let dx = self.x - vector.x
        let dy = self.y - vector.y
        let dz = self.z - vector.z
        return sqrt(dx * dx + dy * dy + dz * dz)
    }
}


class TestDriveScene: SCNScene, SCNSceneRendererDelegate, ARSCNViewDelegate {
    var carNode: SCNNode?
    var roadNode: SCNNode!
    var obstacles: [SCNNode] = []
    var goalNode: SCNNode!
    var gameTimer: Timer?
    var isGameRunning = false
    var vignetteEffect: SCNNode!
    var energy: Int
    var timeRemaining: Int
    var gameOverMessage: String?
    var sceneView: ARSCNView?
    
    var onGameUpdate: ((Int, Int, String?) -> Void)?
    
    var isGasCar: Bool = true {
        didSet {
            setCarModel()
        }
    }
    
    init(energy: Int, timeRemaining: Int, gameOverMessage: String?, isGasCar: Bool) {
        self.energy = energy
        self.timeRemaining = timeRemaining
        self.gameOverMessage = gameOverMessage
        self.isGasCar = isGasCar
        super.init()
        
        setupScene()
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    
    private func setupScene() {
        sceneView = ARSCNView()
        sceneView?.scene = self
        sceneView?.delegate = self
        sceneView?.automaticallyUpdatesLighting = true
        
        self.background.contents = UIColor.white

        let ground = SCNNode(geometry: SCNPlane(width: 20, height: 40))
        ground.geometry?.firstMaterial?.diffuse.contents = UIColor.gray
        ground.position = SCNVector3(0, -1, 0)
        ground.eulerAngles.x = -.pi / 2
        rootNode.addChildNode(ground)

        for i in 0..<5 {
            let obstacle = createObstacle()
            obstacle.position = SCNVector3(Float.random(in: -2...2), 0, -Float(i) * 5)
            obstacles.append(obstacle)
            rootNode.addChildNode(obstacle)
        }

        setupGoal()
    }
    
    func updateBackground(opacity: CGFloat) {
        let grayValue = max(0, min(1, opacity))
        let backgroundColor = UIColor(white: grayValue, alpha: 1)
        self.background.contents = backgroundColor
    }

    
    func setCarModel() {
        if let car = carNode {
            car.removeFromParentNode()
        }
        
        let modelName = "GasCar.usdz"
        var newCarNode: SCNNode?

        if let url = Bundle.main.url(forResource: modelName, withExtension: nil) {
            do {
                let carScene = try SCNScene(url: url)
                newCarNode = carScene.rootNode.childNodes.first
            } catch {
                print("Error loading \(modelName): \(error.localizedDescription)")
            }
        } else {
            print("File \(modelName) not found in bundle.")
        }

        if newCarNode == nil {
            let defaultGeometry = SCNBox(width: 1, height: 0.5, length: 2, chamferRadius: 0.2)
            defaultGeometry.firstMaterial?.diffuse.contents = isGasCar ? UIColor.red : UIColor.blue
            newCarNode = SCNNode(geometry: defaultGeometry)
        }
        
        guard let carNode = newCarNode else {
            print("Failed to create carNode.")
            return
        }

        carNode.position = SCNVector3(0, 0, 0)

        carNode.physicsBody = SCNPhysicsBody(type: .dynamic, shape: nil)
        carNode.physicsBody?.isAffectedByGravity = false
        carNode.physicsBody?.categoryBitMask = 1
        carNode.physicsBody?.collisionBitMask = 2

        rootNode.addChildNode(carNode)
        
        self.carNode = carNode
    }

    
    private func setupObstacles() {
        for i in 0..<5 {
            let obstacle = createObstacle()
            obstacle.position = SCNVector3(Float.random(in: -2...2), 0, -Float(i) * 10)
            obstacles.append(obstacle)
            rootNode.addChildNode(obstacle)
        }
        
        let moveObstacles = SCNAction.repeatForever(SCNAction.moveBy(x: 0, y: 0, z: 10, duration: 5))
        obstacles.forEach { $0.runAction(moveObstacles) }
    }
    
    private func createObstacle() -> SCNNode {
        let obstacleGeometry = SCNSphere(radius: 0.5)
        obstacleGeometry.firstMaterial?.diffuse.contents = UIColor.green
        
        let obstacleNode = SCNNode(geometry: obstacleGeometry)
        obstacleNode.physicsBody = SCNPhysicsBody(type: .static, shape: nil)
        obstacleNode.physicsBody?.categoryBitMask = 2
        obstacleNode.physicsBody?.collisionBitMask = 1

        return obstacleNode
    }


    
    private func setupGoal() {
        let goalGeometry = SCNSphere(radius: 0.5)
        goalGeometry.firstMaterial?.diffuse.contents = UIColor.yellow
        
        goalNode = SCNNode(geometry: goalGeometry)
        goalNode.position = SCNVector3(Float.random(in: -2...2), 0.5, -25)
        rootNode.addChildNode(goalNode)
    }
    
    private func updateGameLogic() {
        if timeRemaining <= 0 {
            gameOverMessage = energy > 0 ? "You made it to refuel successfully!" : "Game Over!"
            checkGameEnd()
            return
        }

        timeRemaining -= 1
        energy -= 1
        onGameUpdate?(energy, timeRemaining, nil)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            self.updateGameLogic()
        }
    }

        
    
//    vignette
        private func createVignetteEffect() -> SCNNode {
            let plane = SCNPlane(width: 10, height: 10)
            plane.materials.first?.diffuse.contents = UIColor.black.withAlphaComponent(0.5)
            let node = SCNNode(geometry: plane)
            node.position = SCNVector3(0, 0, -2)
            return node
        }
    
//    animations
    
    func moveCar() {
        let moveAction = SCNAction.moveBy(x: 0, y: 0, z: -2, duration: 0.5)
        carNode?.runAction(moveAction, completionHandler: {
            DispatchQueue.main.async {
                let opacity = CGFloat(1 - (Float(self.energy) / 100))
                self.updateBackground(opacity: opacity)
            }
        })
    }

    
    func jumpCar() {
        guard let car = carNode else {
            print("Error: carNode is nil")
            return
        }

        let jumpUp = SCNAction.moveBy(x: 0, y: 1, z: 0, duration: 0.3)
        let jumpDown = SCNAction.moveBy(x: 0, y: -1, z: 0, duration: 0.3)
        let jumpSequence = SCNAction.sequence([jumpUp, jumpDown])
        car.runAction(jumpSequence)
    }

    
    func startGame() {
        if isGameRunning { return }
        
        isGameRunning = true
        timeRemaining = 15
        energy = 100

        gameTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { timer in
            self.timeRemaining -= 1
            self.onGameUpdate?(self.energy, self.timeRemaining, nil)
            
            if self.energy <= 0 || self.timeRemaining <= 0 {
                timer.invalidate()
                self.checkGameEnd()
            }
        }
        
        moveObstacles()
    }

    func checkGameEnd() {
        isGameRunning = false
        gameTimer?.invalidate()
        
        if energy == 0 {
            gameOverMessage = "You ran out of energy! Try again?"
        } else if timeRemaining == 0 {
            gameOverMessage = energy > 20 ? "You made it to the goal!" : "You didn't make it! Try again?"
        }

        onGameUpdate?(energy, timeRemaining, gameOverMessage)
    }

    
    func stopCar() {
        carNode?.removeAllActions()
    }

    
    private func moveObstacles() {
        if isGameRunning{
            for obstacle in obstacles {
                let moveAction = SCNAction.moveBy(x: 0, y: 0, z: 30, duration: 30)
                obstacle.runAction(moveAction)
            }
            let moveGoal = SCNAction.moveBy(x: 0, y: 0, z: 30, duration: 30)
            goalNode.runAction(moveGoal)
        }
    }
    
    private func setupStartButton() {
        let startButton = SCNNode(geometry: SCNPlane(width: 3, height: 1))
        startButton.geometry?.firstMaterial?.diffuse.contents = UIColor.green
        startButton.name = "startButton"
        startButton.position = SCNVector3(0, 1, 0)
        rootNode.addChildNode(startButton)
    }
    
    func checkCollision() {
        guard let car = carNode else { return }

        for obstacle in obstacles {
            guard let obstacleNode = obstacle as? SCNNode else { continue }

            if car.position.z < obstacleNode.position.z + 1.0 &&
               car.position.z > obstacleNode.position.z - 1.0 {
                if abs(car.position.x - obstacleNode.position.x) < 1.0 {
                    reduceEnergy()
                }
            }
        }
    }

    
    func renderer(_ renderer: SCNSceneRenderer, didSimulatePhysicsAtTime time: TimeInterval) {
        DispatchQueue.main.async {
            self.onGameUpdate?(self.energy, self.timeRemaining, self.gameOverMessage)
        }
        
        let roadWidth: Float = 20.0

        if let car = carNode {
            if abs(car.presentation.position.x) > roadWidth / 2 {
                gameOverMessage = "You went off the road!"
                checkGameEnd()
                return
            }

            for obstacle in obstacles {
                if let obstacleNode = obstacle as? SCNNode {
                    if car.presentation.worldPosition.distance(to: obstacleNode.presentation.worldPosition) < 0.5 {
                        handleCollision()
                    }
                }
            }
        }
    }


        

    func handleCollision() {
        energy = max(0, energy - 15)
        onGameUpdate?(energy, timeRemaining, nil)

        if let car = carNode {
            car.position.y = 0
            
            let moveLeft = SCNAction.moveBy(x: -0.5, y: 0, z: 0, duration: 0.1)
            let moveRight = SCNAction.moveBy(x: 1.0, y: 0, z: 0, duration: 0.2)
            let moveBack = SCNAction.moveBy(x: -0.5, y: 0, z: 0, duration: 0.1)
            let sequence = SCNAction.sequence([moveLeft, moveRight, moveBack])
            
            car.runAction(sequence)
        }

        if energy <= 0 {
            checkGameEnd()
        }
    }




        
        func reduceEnergy() {
            energy -= 20
            let opacity = CGFloat(1 - (Float(energy) / 100))
            SCNTransaction.begin()
            SCNTransaction.animationDuration = 0.3
            updateBackground(opacity: opacity)
            SCNTransaction.commit()
        }
        
    private func endGame() {
        isGameRunning = false
        gameTimer?.invalidate()
        
        let fadeOut = SCNAction.fadeOut(duration: 1)
        
        carNode?.runAction(fadeOut)
    }

    
    private func winGame() {
        gameTimer?.invalidate()
        isGameRunning = false
        let victoryAction = SCNAction.scale(to: 1.5, duration: 1)
        goalNode.runAction(victoryAction)
    }
    
}
