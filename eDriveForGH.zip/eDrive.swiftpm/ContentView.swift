import Foundation
import SwiftUI

struct ContentView: View {
    @ObservedObject var coordinator = AppCoordinator.shared

    var body: some View {
        NavigationStack(path: $coordinator.navigationPath) {
            HomeView()
                .navigationDestination(for: AppView.self) { view in
                    switch view {
                    case .home:
                        HomeView()
                    case .tutorial:
                        TutorialView()
                    case .crashCourse:
                        CrashCourseView()
                    case .testDrive:
                        TestDriveView()
                    case .fuelCalc:
                        FuelCalcView()
                    case .quiz:
                        PracticeQuizView()
                    }
                }
        }
    }
}
