//
//  File.swift
//  eDrive
//
//  Created by sd on 2/14/25.
//

import Foundation
import SwiftUI

struct CreditsView: View {
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        VStack {
            HStack {
                Spacer()
                Button(action: { dismiss() }) {
                    Image(systemName: "xmark.circle.fill")
                        .font(.largeTitle)
                        .foregroundColor(.gray)
                }
                .padding()
            }
            
            Text("🙏 Credits")
                .font(.largeTitle)
                .bold()
                .foregroundColor(.black)
                .padding(.bottom, 20)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 10) {
                    Divider().padding(.vertical)
                
                    Text("Information and Tech Credits:")
                        .font(.headline)
                        .foregroundColor(.black)
                    Text("• Use of Perplexity AI to assist with compiling formatted data for Fuels.")
                        .foregroundColor(.black)
                    Text("• Referenced Dept. of Energy, specifically Alternative Fuel and Advanced Vehicle Search and https://afdc.energy.gov/fuels.")
                        .foregroundColor(.black)
                    Text("• Referenced UK's Vehicle Certification Agency's page, New Car Fuel Consumption & Emission Figures")
                        .foregroundColor(.black)
                    
                    Divider().padding(.vertical)
                    
                    Group {
                        Text("Powered by:")
                            .font(.headline)
                            .foregroundColor(.black)
                        Text("• SwiftUI, RealityKit, ARKit")
                            .foregroundColor(.black)
                        Text("• Created scenes in Reality Composer Pro and Reality Composer")
                            .foregroundColor(.black)
                        
                        Divider().padding(.vertical)
                        
                        Text("Poly.pizza Models Credits:")
                            .font(.headline)
                            .foregroundColor(.black)
                        Text("[CC-BY]:")
                            .font(.subheadline)
                            .foregroundColor(.black)
                        Text("• (Green) car by Username12")
                            .foregroundColor(.black)
                        Text("• Red car by J-Toastie")
                            .foregroundColor(.black)
                        Text("• Car battery by J-Toastie")
                            .foregroundColor(.black)
                        Text("• (Yellow car) 1972 Bursley Defiance by Grzybek")
                            .foregroundColor(.black)
                        Text("• Gas Can by Quaternius")
                            .foregroundColor(.black)
                        Text("• Parking Lot by Alex Safayan")
                            .foregroundColor(.black)
                        Text("• Parking Meter by Zsky")
                            .foregroundColor(.black)
                        Text("• Steering wheel by Poly by Google")
                            .foregroundColor(.black)
                        Text("• (Charging cable) TIME HOTEL 2.15 by S. Paul Michael")
                            .foregroundColor(.black)
                        Text("• Truck by sugamo")
                            .foregroundColor(.black)
                    }
                    
                    Group {
                        Text("CC0 1.0 Universal Public Domain:")
                            .font(.subheadline)
                            .padding(.top)
                            .foregroundColor(.black)
                        Text("• Smoke by Quaternius")
                            .foregroundColor(.black)
                        Text("• Sports car by Quaternius")
                            .foregroundColor(.black)
                        Text("• Key With Tag by iPoly3D")
                            .foregroundColor(.black)
                        
                        Divider().padding(.vertical)
                        
                        Text("Sounds:")
                            .font(.headline)
                            .foregroundColor(.black)
                        Text("Created by me in Garageband using instruments and tapping!")
                            .foregroundColor(.black)
                        
                        Divider().padding(.vertical)
                    }
                }
                .padding(.horizontal, 30)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .background(Color.white)
    }
}
