//
//  File.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation

class TestDriveViewModel: ObservableObject {
    @Published var isCarSelected: Bool = false
    var controller: TestDriveARViewController?
    
    @MainActor func moveCar(forward: Bool) {
        guard isCarSelected else {
            print("No car selected!")
            return
        }
        controller?.moveCar(forward: forward)
    }
    
    @MainActor func selectCar(isElectric: Bool) {
        controller?.selectCar(isElectric: isElectric)
        isCarSelected = true
    }
}
