//
//  CameraView.swift
//  eDrive Playground
//
//  Created by sd on 2/23/25.
//

import SwiftUI
import AVFoundation
import Vision

struct CameraView: UIViewControllerRepresentable {
    @Binding var handPoints: [CGPoint]
    
    func makeUIViewController(context: Context) -> CameraViewController {
        let controller = CameraViewController()
        controller.handPointsBinding = $handPoints
        return controller
    }

    func updateUIViewController(_ uiViewController: CameraViewController, context: Context) {}
}

class CameraViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate {
    var captureSession = AVCaptureSession()
    var handPointsBinding: Binding<[CGPoint]>?
    private var previewLayer: AVCaptureVideoPreviewLayer!
    private var overlayView = UIView()

    override func viewDidLoad() {
        super.viewDidLoad()
        setupCamera()
        setupOverlayView()
    }

    private func setupCamera() {
        captureSession.sessionPreset = .high
        guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else { return }

        do {
            let input = try AVCaptureDeviceInput(device: camera)
            captureSession.addInput(input)
        } catch {
            print("Error accessing camera: \(error)")
            return
        }
        

        let videoOutput = AVCaptureVideoDataOutput()
        videoOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        captureSession.addOutput(videoOutput)

        previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        previewLayer.videoGravity = .resizeAspectFill
        view.layer.addSublayer(previewLayer)

        captureSession.startRunning()
        captureSession.sessionPreset = .medium
        
        setupOverlayView()
    }

    
    private func setupOverlayView() {
        overlayView.backgroundColor = .clear
        view.addSubview(overlayView)
    }

    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer.frame = view.bounds
        overlayView.frame = previewLayer.frame
    }


    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let request = VNDetectHumanHandPoseRequest { request, error in
            guard let observations = request.results as? [VNHumanHandPoseObservation], let hand = observations.first else {
                DispatchQueue.main.async {
                    self.overlayView.subviews.forEach { $0.removeFromSuperview() }
                }
                return
            }
            
            let keyJoints: [VNHumanHandPoseObservation.JointName] = [.thumbTip, .indexTip]

            DispatchQueue.main.async {
                let overlayBounds = self.overlayView.bounds
                var newPoints: [CGPoint] = []

                for joint in keyJoints {
                    if let point = try? hand.recognizedPoint(joint), point.confidence > 0.3 {
                        let convertedPoint = CGPoint(
                            x: overlayBounds.width * point.location.x,
                            y: overlayBounds.height * (1 - point.location.y) 
                            )
                        newPoints.append(convertedPoint)
                    }
                }

                self.overlayView.subviews.forEach { $0.removeFromSuperview() }
                self.handPointsBinding?.wrappedValue = newPoints
                self.drawTrackingDots(points: newPoints)
            }

        }

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: [:])
        try? handler.perform([request])
    }

    private func drawTrackingDots(points: [CGPoint]) {
        overlayView.subviews.forEach { $0.removeFromSuperview() }
        
        for point in points {
            let dot = UIView(frame: CGRect(x: point.x - 5, y: point.y - 5, width: 10, height: 10))
            dot.backgroundColor = .red
            dot.layer.cornerRadius = 5
            overlayView.addSubview(dot)
        }
    }
}
