//
//  FuelViewHelpers.swift
//  eDrive Playground
//
//  Created by sd on 2/23/25.
//

struct Fuel : Equatable {
    let name: String
    let formula: String
    let energyDensity: Double?
    let combustible: Bool
    let compatibleWith: String
}


let fuelDatabase: [String: Fuel] = [
    "C2H2O0": Fuel(name: "Acetylene", formula: "C2H2O0", energyDensity: 48.0, combustible: true, compatibleWith: "Welding Equipment, Torches"),
    "C8H18O0": Fuel(name: "Octane", formula: "C8H18O0", energyDensity: 47.0, combustible: true, compatibleWith: "Gasoline"),
    "C2H6O1": Fuel(name: "Ethanol", formula: "C2H6O1", energyDensity: 30.0, combustible: true, compatibleWith: "Gasoline, Ethanol Blend"),
    "C0H2O1": Fuel(name: "Water", formula: "C0H2O1", energyDensity: nil, combustible: false, compatibleWith: "None"),
    "C3H8O0": Fuel(name: "Propane", formula: "C3H8O0", energyDensity: 46.4, combustible: true, compatibleWith: "Gasoline (LPG)"),
    "C0H2O0": Fuel(name: "Hydrogen", formula: "C0H2O0", energyDensity: 120.0, combustible: true, compatibleWith: "Fuel Cells"),
    "C4H10O0": Fuel(name: "Butane", formula: "C4H10O0", energyDensity: 45.6, combustible: true, compatibleWith: "Gasoline (LPG)"),
    "C12H26O0": Fuel(name: "Diesel", formula: "C12H26O0", energyDensity: 45.5, combustible: true, compatibleWith: "Diesel Engines"),
    "C14H30": Fuel(name: "Kerosene", formula: "C14H30", energyDensity: 43.0, combustible: true, compatibleWith: "Jet Engines, Heating"),
    "C6H6O0": Fuel(name: "Benzene", formula: "C6H6O0", energyDensity: 40.5, combustible: true, compatibleWith: "Gasoline (Aromatics)"),
    "C7H8O0": Fuel(name: "Toluene", formula: "C7H8O0", energyDensity: 41.0, combustible: true, compatibleWith: "Octane Booster"),
    "C2H4O2": Fuel(name: "Acetic Acid", formula: "C2H4O2", energyDensity: 14.5, combustible: false, compatibleWith: "None"),
    "C3H8O3": Fuel(name: "Glycerol", formula: "C3H8O3", energyDensity: 16.0, combustible: false, compatibleWith: "Biofuel Feedstock"),
    "C10H20": Fuel(name: "Jet Fuel (JP-8)", formula: "C10H20", energyDensity: 43.1, combustible: true, compatibleWith: "Jet Engines"),
    "C2H6O2": Fuel(name: "Ethylene Glycol", formula: "C2H6O2", energyDensity: 26.0, combustible: false, compatibleWith: "Coolant"),
    "C5H12O0": Fuel(name: "Pentane", formula: "C5H12O0", energyDensity: 45.0, combustible: true, compatibleWith: "Gasoline"),
    "C1H4O1": Fuel(name: "Methanol", formula: "C1H4O1", energyDensity: 22.7, combustible: true, compatibleWith: "Methanol Fuel Cells"),
    "C1H4O0": Fuel(name: "Methane", formula: "C1H4O0", energyDensity: 55.5, combustible: true, compatibleWith: "Natural Gas Vehicles"),
    "C18H32O2": Fuel(name: "Biodiesel (Soybean Oil)", formula: "C18H32O2", energyDensity: 38.0, combustible: true, compatibleWith: "Diesel Engines"),
    "C12H22O11": Fuel(name: "Sucrose", formula: "C12H22O11", energyDensity: 16.5, combustible: false, compatibleWith: "Ethanol Production"),
    "C8H10O0": Fuel(name: "Xylene", formula: "C8H10O0", energyDensity: 41.6, combustible: true, compatibleWith: "Octane Booster, Solvent"),
    "C3H6O1": Fuel(name: "Acetone", formula: "C3H6O1", energyDensity: 29.0, combustible: true, compatibleWith: "Alternative Fuel Additive"),
    "C4H8O1": Fuel(name: "Butanone (MEK)", formula: "C4H8O1", energyDensity: 31.0, combustible: true, compatibleWith: "Solvent, Fuel Additive"),
    "C5H10O0": Fuel(name: "Cyclopentane", formula: "C5H10O0", energyDensity: 45.3, combustible: true, compatibleWith: "Gasoline"),
    "C6H12O0": Fuel(name: "Cyclohexane", formula: "C6H12O0", energyDensity: 46.6, combustible: true, compatibleWith: "Gasoline"),
    "C7H14O0": Fuel(name: "Methylcyclohexane", formula: "C7H14O0", energyDensity: 44.0, combustible: true, compatibleWith: "Hydrogen Carrier"),
    "C3H6O2": Fuel(name: "Propylene Glycol", formula: "C3H6O2", energyDensity: 23.0, combustible: false, compatibleWith: "Coolant, Antifreeze"),
    "C2H4O1": Fuel(name: "Ethylene Oxide", formula: "C2H4O1", energyDensity: 32.0, combustible: true, compatibleWith: "Chemical Synthesis"),
    "C6H14O1": Fuel(name: "Hexanol", formula: "C6H14O1", energyDensity: 36.0, combustible: true, compatibleWith: "Biofuels"),
    "C7H16O1": Fuel(name: "Heptanol", formula: "C7H16O1", energyDensity: 37.5, combustible: true, compatibleWith: "Biofuels"),
    "C8H18O1": Fuel(name: "Octanol", formula: "C8H18O1", energyDensity: 39.0, combustible: true, compatibleWith: "Biofuels"),
    "C5H10O1": Fuel(name: "Methyl Butanone", formula: "C5H10O1", energyDensity: 33.0, combustible: true, compatibleWith: "Fuel Additive, Solvent"),
    "C9H20O0": Fuel(name: "Nonane", formula: "C9H20O0", energyDensity: 44.5, combustible: true, compatibleWith: "Aviation Fuel, Gasoline"),
    "C10H22O0": Fuel(name: "Decane", formula: "C10H22O0", energyDensity: 44.0, combustible: true, compatibleWith: "Diesel, Kerosene"),
    "C12H26O2": Fuel(name: "Dodecanol", formula: "C12H26O2", energyDensity: 42.5, combustible: true, compatibleWith: "Biofuels, Surfactants")
]


func getFuelInfo(c: Int, h: Int, o: Int) -> Fuel {
    let formula = "C\(c)H\(h)O\(o)"
    
    if formula == "C0H0O0" {
        return Fuel(name: "Invalid Input", formula: formula, energyDensity: nil, combustible: false, compatibleWith: "None")
    }
    
    if let existingFuel = fuelDatabase[formula] {
        return existingFuel
    }
    
    let closestFuel = fuelDatabase.values.min(by: { abs($0.energyDensity ?? 0 - Double((4*c + h - 2*o) * 2)) < abs($1.energyDensity ?? 0 - Double((4*c + h - 2*o) * 2)) })

    let estimatedEnergyDensity = closestFuel?.energyDensity ?? (4.0 * Double(c) + 1.0 * Double(h) - 2.0 * Double(o))

    let afr = computeAFR(c: c, h: h, o: o)
    let isCombustible = afr > 0

    return Fuel(
        name: "Unknown Molecule",
        formula: formula,
        energyDensity: estimatedEnergyDensity,
        combustible: isCombustible,
        compatibleWith: isCombustible ? "Potential Fuel" : "Not Usable"
    )
}


func computeAFR(c: Int, h: Int, o: Int) -> Double {
    //    @shiv change according to hydrocarbons** CHO input matters
    let fuelMass = (12.0 * Double(c) + 1.0 * Double(h) + 16.0 * Double(o))
    let oxygenMass = (32.0 * (Double(c) + Double(h) / 4.0 - Double(o)))

    return fuelMass == 0 ? 0 : oxygenMass / fuelMass
}
