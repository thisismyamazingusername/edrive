//
//  File.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation
import UIKit
import RealityKit
import ARKit

class TestDriveARViewController: UIViewController, ARSessionDelegate {
    var arView: ARView!
    var carEntity: Entity?
    var gasCarEntity: Entity?
    var selectedCar: Entity?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        arView = ARView(frame: view.frame)
        view.addSubview(arView)
        
        let config = ARWorldTrackingConfiguration()
        config.planeDetection = [.horizontal]
        config.environmentTexturing = .automatic
        arView.session.run(config)
        arView.session.delegate = self
        
        setupHandTracking()
        loadCarModels()
        spawnFloatingObstacles()
    }
    
    func setupHandTracking() {
        let handPoseRequest = VNDetectHumanHandPoseRequest()
        handPoseRequest.maximumHandCount = 1
        
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { _ in
            self.detectHandPose(request: handPoseRequest)
        }
    }
    
    func detectHandPose(request: VNDetectHumanHandPoseRequest) {
        guard let currentFrame = arView.session.currentFrame else { return }
        let handler = VNImageRequestHandler(cvPixelBuffer: currentFrame.capturedImage, options: [:])
        
        do {
            try handler.perform([request])
            if let results = request.results, let observation = results.first {
                let handPoints = try observation.recognizedPoints(.all)
                let thumbTip = handPoints[.thumbTip]?.location ?? .zero
                let indexTip = handPoints[.indexTip]?.location ?? .zero
                
                let isFlatHand = abs(thumbTip.y - indexTip.y) < 0.05
                
                DispatchQueue.main.async {
                    if isFlatHand {
                        self.moveCar(forward: true)
                    } else {
                        self.stopCar()
                    }
                }
            }
        } catch {
            print("Error detecting hand pose: \(error)")
        }
    }
    
    func loadCarModels() {
        do {
            let cyberTruck = try Entity.load(named: "CyberTruck")
            let gasCar = try Entity.load(named: "GasCar")
            
            let anchor = AnchorEntity(plane: .horizontal)
            cyberTruck.position = [0, 0, -1]
            gasCar.position = [1, 0, -1]
            
            anchor.addChild(cyberTruck)
            anchor.addChild(gasCar)
            
            arView.scene.anchors.append(anchor)
            self.carEntity = cyberTruck
            self.gasCarEntity = gasCar
        } catch {
            print("Failed to load car models: \(error)")
        }
    }
    
    func selectCar(isElectric: Bool) {
        selectedCar = isElectric ? carEntity : gasCarEntity
        print("Selected car: \(isElectric ? "CyberTruck" : "GasCar")")
    }

    
    func moveCar(forward: Bool) {
        guard let car = selectedCar else { return }
        let moveDistance: Float = forward ? 0.5 : -0.5
        car.move(to: Transform(translation: [moveDistance, 0, 0]), relativeTo: car)
    }
    
    func stopCar() {
    }
    
    func spawnFloatingObstacles() {
        for _ in 1...5 {
            let obstacle = ModelEntity(mesh: .generateSphere(radius: 0.1))
            obstacle.position = [Float.random(in: -1...1), Float.random(in: 0.5...2), Float.random(in: -1.5...1)]
            obstacle.generateCollisionShapes(recursive: true)
            arView.scene.addAnchor(AnchorEntity(world: obstacle.position))
        }
    }
}
