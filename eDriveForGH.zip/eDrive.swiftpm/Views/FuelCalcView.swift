//
//  File.swift
//  eDrive
//
//  Created by sd on 2/14/25.
//
//

import SwiftUI

struct FuelCalcView: View {
    @State private var carbon = 0
    @State private var hydrogen = 0
    @State private var oxygen = 0
    @State private var fuelInfo: Fuel?
    @State private var checkingText = "Checking..."
    @State private var fuelBubbles: [Fuel] = []
    @State private var showPopup = true
    @State private var fuelIndex = 0
    let fuelList = Array(fuelDatabase.values)
    @State private var infoVisible = false
    @StateObject private var audioManager = AudioManager()
   
    
    var body: some View {
        ZStack{
//            Color.gray.edgesIgnoringSafeArea(.all)
//            @shiv this is making the number inc hard to see... how to fix???
//        MeshBackground(color1: .black, color2: .gray, color3: .blue)
            MeshBackground(color1: .black, color2: .blue, color3: .green)

            VStack {
                if !showPopup {
                HStack{
                    Text("Fuel Types and Sustainability").font(.largeTitle).bold().padding().foregroundColor(.black)
                    //  show da popup
                    Button("Read more") {
                        showPopup = true
                    }
                    .padding()
                    .background(Color.blue.opacity(0.5))
                    .foregroundColor(.black)
                    .cornerRadius(10)
                }
            }
                ScrollView{
            if !showPopup {
                
                Text("Calculator")
                    .font(.largeTitle).bold()
                    .padding()
                    .foregroundColor(.black)
                
                VStack(spacing: 15) {
                    StepperView(title: "(C)arbon", value: $carbon, onEditingChanged: updateFuel)
                    StepperView(title: "(H)ydrogen", value: $hydrogen, onEditingChanged: updateFuel)
                    StepperView(title: "(O)xygen", value: $oxygen, onEditingChanged: updateFuel)
                }
                
                Text(checkingText)
                    .italic()
                    .foregroundColor(.white)
                    .padding()
                
                HStack {
                if let fuel = fuelInfo {
                    VStack(spacing: 10) {
                        Text("Molecule: \(fuel.name)").font(.headline).bold().foregroundColor(.black)
                        
                        VStack(spacing: 5) {
                            if let energy = fuel.energyDensity {
                                Text("Energy Density: \(energy) MJ/kg")
                            } else {
                                Text("Energy Density: Not a fuel")
                            }
                            Text("Combustible: \(fuel.combustible ? "Yes" : "No")")
                            Text("Vehicle Compatibility: \(fuel.compatibleWith)")
                            Text("Air-Fuel Ratio: \(String(format: "%.2f", computeAFR(c: carbon, h: hydrogen, o: oxygen)))") ///////
                        }
                        .padding()
                        .background(RoundedRectangle(cornerRadius: 10).fill(Color.blue.opacity(0.4)))
                        .foregroundColor(.black)
                    }
                    .padding()
                    }
                
                
                    VStack {
                        if let category = fuelCategory {
                                        HStack {
                                            Text(category.0)
                                                .font(.caption)
                                                .padding(5)
                                                .background(category.1)
                                                .cornerRadius(5)
                                                .foregroundColor(.black)
                                            
                                            // 'i' info button
                                            Button(action: {
                                                withAnimation {
                                                    infoVisible = true
                                                }
                                                // Auto-hide after 10 seconds
                                                DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
                                                    withAnimation {
                                                        infoVisible = false
                                                    }
                                                }
                                            }) {
                                                Image(systemName: "info.circle")
                                                    .foregroundColor(.white)
                                                    .padding(5)
                                            }
                                        }

                                        // Expanded info that fades out after 10 seconds
                                        if infoVisible {
                                            Text(getCategoryDescription(category.0))
                                                .font(.caption2)
                                                .padding(8)
                                                .foregroundColor(.black)
                                                .background(Color.white.opacity(0.9))
                                                .cornerRadius(8)
                                                .transition(.opacity)
                                        }
                                    }
                    }
                    .padding()
                    
            }
                
                Spacer()
                HStack{
                    Text("Need inspiration for your own molecule? Click on one of these bubbles!").font(.subheadline).padding().foregroundColor(.black)
                    Button("Ready? Take the test") {
                        AppCoordinator.shared.navigate(to: .quiz)
                    }
                    .padding()
                    .background(Color.blue.opacity(0.7))
                    .foregroundColor(.black)
                    .cornerRadius(10)
                }
                
                ZStack {
                    GeometryReader { geometry in
                        ForEach(fuelBubbles, id: \.name) { fuel in
                            Text(fuel.name)
                                .padding(10)
                                .background(RoundedRectangle(cornerRadius: 20).fill(Color.blue.opacity(0.8)))
                                .foregroundColor(.black)
                                .position(
                                    x: CGFloat.random(in: 50...(geometry.size.width - 50)),
                                    y: CGFloat.random(in: 50...(geometry.size.height - 50))
                                )
                                .onTapGesture {
                                    selectFuel(fuel)
                                }
                                .animation(Animation.linear(duration: 3).repeatForever(), value: fuelBubbles)
                        }
                    }
                    .frame(height: 300)
                    }

                }
            }
                .padding()
                .onAppear {
                    startFuelBubbles()
                }
                .overlay(
                    FuelInfoPopup(isPresented: $showPopup)
                )
            }
        }.onAppear {
            audioManager.playBackgroundSound()
        }
        .onDisappear {
            audioManager.stopBackgroundSound()
        }
    }

    var fuelCategory: (String, Color)? {
        if let fuel = fuelInfo {
            return categorizeFuel(fuel)
        }
        return nil
    }


    func categorizeFuel(_ fuel: Fuel) -> (String, Color)? {
        if fuel.formula == "C0H0O0" {
            return nil
        }
            
        if let exactFuel = fuelDatabase[fuel.formula] {
            if exactFuel.combustible {
                if exactFuel.formula.contains("H2") || exactFuel.name.contains("Biodiesel") || exactFuel.name.contains("Ethanol") {
                    return ("Sustainable", .green)
                } else if exactFuel.formula.contains("C2H2") || exactFuel.name.contains("Benzene") || exactFuel.name.contains("Toluene") {
                    return ("Unstable", .red)
                } else if let energyDensity = exactFuel.energyDensity, energyDensity > 40.0 {
                    return ("Efficient.", .blue)
                }
                return ("Combustible", .orange)
            } else {
                return ("Non-Combustible", .gray)
            }
        }

        if fuel.combustible {
            if fuel.formula.contains("H2") || fuel.name.contains("Biodiesel") || fuel.name.contains("Ethanol") {
                return ("Sustainable", .green)
            } else if fuel.formula.contains("C2H2") || fuel.name.contains("Benzene") || fuel.name.contains("Toluene") {
                return ("Unstable", .red)
            } else if let energyDensity = fuel.energyDensity, energyDensity > 40.0 {
                return ("Efficient", .blue)
            }
            return ("Combustible", .orange)
        }

        return ("Non-Combustible", .gray)
    }

    
    func getCategoryDescription(_ category: String) -> String {
        switch category {
        case "Sustainable":
            return "Hydrogen, Biodiesel, and Ethanol are sustainable fuels from renewable resources, reducing carbon emissions."
        case "Unstable":
            return "Acetylene, Benzene, and Toluene are unstable due to molecular structures that make them prone to explosion or rapid decomposition."
        case "Efficient":
            return "Fuels with an energy density >40.0 MJ/kg are efficient, releasing significant energy per unit mass."
        case "Combustible":
            return "This fuel burns but doesn't fall into sustainable, unstable, or high-efficiency categories."
        case "Non-Combustible":
            return "This fuel does not ignite or support combustion."
        default:
            return "No additional information available."
        }
    }
    
    func updateFuel() {
        checkingText = "Checking..."
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            fuelInfo = getFuelInfo(c: carbon, h: hydrogen, o: oxygen)
            checkingText = fuelInfo == nil ? "Not a known fuel" : ""
        }
    }
    
    func selectFuel(_ fuel: Fuel) {
        let formula = fuel.formula
        let regex = try! NSRegularExpression(pattern: "C(\\d+)H(\\d+)O(\\d+)")
        if let match = regex.firstMatch(in: formula, range: NSRange(location: 0, length: formula.utf16.count)) {
            if let cRange = Range(match.range(at: 1), in: formula),
               let hRange = Range(match.range(at: 2), in: formula),
               let oRange = Range(match.range(at: 3), in: formula) {
                
                carbon = Int(formula[cRange]) ?? 0
                hydrogen = Int(formula[hRange]) ?? 0
                oxygen = Int(formula[oRange]) ?? 0
                
                updateFuel()
            }
        }
    }
    
    func startFuelBubbles() {
        let sortedFuels = fuelDatabase.keys.sorted()

        Timer.scheduledTimer(withTimeInterval: 2.5, repeats: true) { _ in
            withAnimation {
                if fuelIndex < sortedFuels.count {
                    let key = sortedFuels[fuelIndex]
                    if let fuel = fuelDatabase[key] {
                        fuelBubbles.append(fuel)
                    }
                    fuelIndex += 1
                } else {
                    fuelIndex = 0
                }

                DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
                    if !fuelBubbles.isEmpty {
                        fuelBubbles.removeFirst()
                    }
                }
            }
        }
    }
}


// add id or use formula? "the ID C2H2 occurs multiple times within the collection, this will give undefined results"
