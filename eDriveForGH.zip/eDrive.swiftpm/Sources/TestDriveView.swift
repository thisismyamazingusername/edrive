//
//  File.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation
import SwiftUI
import RealityKit
import ARKit
import SceneKit
import Vision

extension Array {
    subscript(safe index: Int) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}

struct TestDriveView: View {
    @State private var isGasCar = true
    @State private var handPoints: [CGPoint] = []
    @State private var energy = 100
    @State private var timeRemaining = 15
    @State private var gameOverMessage: String?
    @State private var gameScene: TestDriveScene? = nil
    @State private var vignetteOpacity: Double = 0.0
    @State private var showInstructions = true
    @State private var gameStarted = false

    var body: some View {
           ZStack {
               Color.black
                       .ignoresSafeArea()

               if !showInstructions {
                   VStack {
                       EnergyBar(energy: energy)
                       Text("Time Left: \(timeRemaining) | Energy: \(energy)")
                           .font(.headline)
                           .foregroundColor(.white)


                       if let gameScene = gameScene {
                           SceneKitView(scene: gameScene)
                               .frame(height: 300)
                       }

                       VStack {
                           HStack {
                               Button("Gas Car") {
                                   isGasCar = true
                                   restartScene()
                               }
                               .padding()
                               .background(isGasCar ? Color.red : Color.gray)
                               .cornerRadius(10)

                               Button("Electric Car") {
                                   isGasCar = false
                                   restartScene()
                               }
                               .padding()
                               .background(!isGasCar ? Color.blue : Color.gray)
                               .cornerRadius(10)

                               
                               Button("Restart!") {
                                   gameStarted = true
                                   restartScene()
                               }
                               .padding()
                               .background(Color.black.opacity(0.3))
                               .cornerRadius(10)
                           }

                           CameraView(handPoints: $handPoints)
                               .frame(height: 400)
                       }
                   }
                   .onChange(of: handPoints) {
                       processHandTracking(points: handPoints)
                   }
                   .onChange(of: gameScene?.energy) { oldValue, newValue in
                       if let newEnergy = newValue {
                           energy = newEnergy
                       }
                   }
               }

               if showInstructions {
                   GameUIHelpers.instructionPopup {
                       showInstructions = false
                   }
               }

               if let message = gameOverMessage {
                   GameUIHelpers.gameOverPopup(message: message) {
                       gameOverMessage = nil
                       gameScene?.startGame()
                   }
               }

           }
           .onAppear {
               gameScene = TestDriveScene(energy: energy, timeRemaining: timeRemaining, gameOverMessage: gameOverMessage, isGasCar: isGasCar)
               gameScene?.onGameUpdate = { updatedEnergy, updatedTime, message in
                   energy = updatedEnergy
                   timeRemaining = updatedTime
                   gameOverMessage = message
               }
           }
       }
    
    
    func restartScene() {
        gameStarted = false
        gameOverMessage = nil
        energy = 100
        timeRemaining = 15
        showInstructions = false

        gameScene = TestDriveScene(energy: energy, timeRemaining: timeRemaining, gameOverMessage: gameOverMessage, isGasCar: isGasCar)
        gameScene?.isGasCar = isGasCar
        gameScene?.setCarModel()

        gameScene?.onGameUpdate = { newEnergy, newTime, message in
            self.energy = newEnergy
            self.timeRemaining = newTime
            self.gameOverMessage = message
        }
    }

    
    func processHandTracking(points: [CGPoint]) {
        guard points.count >= 2 else { return }

        let indexTip = points[1]
          let thumbTip = points[0]
          let distance = hypot(indexTip.x - thumbTip.x, indexTip.y - thumbTip.y)

//        @shiv 40 too much for iphone testing, check on ipad
          if distance < 10 && points.count == 2 {
              gameScene?.jumpCar()
        }

        vignetteOpacity = (energy <= 0 || (gameScene?.energy ?? 0 < 50 && (gameScene?.energy ?? 0) % 10 == 0)) ? 0.5 : 0.0
    }
}


// views

struct SceneKitView: UIViewRepresentable {
    var scene: SCNScene

    func makeUIView(context: Context) -> SCNView {
        let view = SCNView()
        view.scene = scene
        view.allowsCameraControl = true
        view.backgroundColor = .black
        return view
    }

    func updateUIView(_ uiView: SCNView, context: Context) {}
}

struct EnergyBar: View {
    var energy: Int
    
    var body: some View {
        ZStack(alignment: .leading) {
            Rectangle()
                .fill(Color.gray.opacity(0.3))
                .frame(width: 200, height: 10)
                .cornerRadius(5)

            Rectangle()
                .fill(energy > 50 ? Color.green : (energy > 30 ? Color.yellow : Color.red))
                .frame(width: CGFloat(energy) * 2, height: 10)
                .cornerRadius(5)
        }
        .padding()
    }
}
