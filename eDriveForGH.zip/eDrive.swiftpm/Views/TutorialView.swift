import SwiftUI

struct TutorialView: View {
    @ObservedObject var coordinator = AppCoordinator.shared
    @State private var stepIndex = 0
    @Environment(\.dismiss) var dismiss
    @StateObject private var audioManager = AudioManager()
    
    let tutorialSteps = [
        "Welcome to eDrive!",
        "Learn about common vehicles, fuel sources, and their environmental sustainability.",
        "1️⃣ Immerse yourself in augmented reality (AR) experiences with Crash Course. For the best experience, use the camera in front of a blank space or wall and turn up the sound.",
        "2️⃣ Visualize sustainability in Test Drive.",
        "3️⃣ Experiment with making new potential fuel molecules in Fuel Factory",
        "4️⃣ Take a quiz to test your knowledge and compare results with your friends!",
        "Let's get started with Crash Course!"
    ]
    
    var body: some View {
        ZStack {
            MeshBackground(color1: .black, color2: .yellow, color3: .blue)
            VStack {
                Text(tutorialSteps[stepIndex])
                    .font(.title2)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Button("Next") {
                    if stepIndex < tutorialSteps.count - 1 {
                        stepIndex += 1
                    } else {
                        dismiss()
                    }
                }
                .padding()
                .buttonStyle(.borderedProminent)
            }
            .padding()
        }
        .ignoresSafeArea()
        .onAppear {
            audioManager.playBackgroundSound()
        }
        .onDisappear {
            audioManager.stopBackgroundSound()
        }
    }
}
