//
//  ARTestDriveView.swift
//  eDrive Playground
//
//  Created by sd on 2/22/25.
//

import SwiftUI
import ARKit
import RealityKit

struct ARTestDriveView: UIViewControllerRepresentable {
    @ObservedObject var viewModel: TestDriveViewModel

    func makeUIViewController(context: Context) -> TestDriveARViewController {
        let controller = TestDriveARViewController()
        viewModel.controller = controller
        return controller
    }

    func updateUIViewController(_ uiViewController: TestDriveARViewController, context: Context) {}
}
