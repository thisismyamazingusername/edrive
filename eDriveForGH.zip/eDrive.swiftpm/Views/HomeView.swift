import SwiftUI


struct HomeView: View {
    @State private var showCredits = false
    @ObservedObject var coordinator = AppCoordinator.shared

    var body: some View {
        NavigationStack {
            ZStack {
                MeshBackground(color1: .black, color2: .blue, color3: .red)

                VStack(spacing: 20) {
                    Text("🚗 eDrive ")
                        .font(.largeTitle)
                        .bold()
                    
                    NavigationLink(" Welcome", value: AppView.tutorial)
                        .buttonStyle(MainButtonStyle())
                    
                    NavigationLink(" Crash Course", value: AppView.crashCourse)
                        .buttonStyle(MainButtonStyle())
                    
                    NavigationLink(" Test Drive", value: AppView.testDrive)
                        .buttonStyle(MainButtonStyle())
                    
                    NavigationLink(" Fuel Factory", value: AppView.fuelCalc)
                        .buttonStyle(MainButtonStyle())
                    
                    NavigationLink(" Quiz", value: AppView.quiz)
                        .buttonStyle(MainButtonStyle())
                    
                    Button("Credits") {
                        showCredits.toggle()
                    }
                    .buttonStyle(CreditsButtonStyle())
                    .padding(.top, 10)
                }
                .padding()
                .sheet(isPresented: $showCredits) {
                    CreditsView()
                }
                .navigationDestination(for: AppView.self) { view in
                    switch view {
                    case .home:
                        HomeView()
                    case .tutorial:
                        TutorialView()
                    case .crashCourse:
                        CrashCourseView()
                    case .testDrive:
                        TestDriveView()
                    case .fuelCalc:
                        FuelCalcView()
                    case .quiz:
                        PracticeQuizView()
                    }
                }
            }
        }
    }
}



struct CreditsButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(maxWidth: 200)
            .padding()
            .background(Color.gray.opacity(0.3))
            .foregroundColor(.black)
            .cornerRadius(10)
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}

struct MainButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .frame(maxWidth: 200)
            .padding()
            .background(Color.blue.opacity(0.7))
            .foregroundColor(.black)
            .cornerRadius(10)
            .scaleEffect(configuration.isPressed ? 0.95 : 1.0)
    }
}

