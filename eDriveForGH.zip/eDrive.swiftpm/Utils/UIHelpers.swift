//
//  UIHelpers.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation
import SwiftUI

// buttons, stepper, transitions?

struct ButtonPressModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .scaleEffect(1.1)
            .animation(.easeInOut(duration: 0.2), value: 1.1)
    }
}

struct UIHelpers {
    static func animateButtonPress() -> some ViewModifier {
        return ButtonPressModifier()
    }
}

struct StepperView: View {
    var title: String
    @Binding var value: Int
    var onEditingChanged: () -> Void

        
    var body: some View {
        VStack(spacing: 10) {
            HStack {
                Text(title)
                    .font(.headline)
                    .bold()
                    .foregroundColor(.black)
                
                Text("\(value)")
                    .font(.headline)
                    .bold()
                    .frame(width: 50, height: 30)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color.white))
                    .foregroundColor(.black)
            }
            
            HStack {
                Spacer()
                Stepper("", value: $value, in: 0...20, onEditingChanged: { _ in onEditingChanged() })
                    .labelsHidden()
                Spacer()
            }
            .frame(maxWidth: 200)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 8).fill(Color.black.opacity(0.2)))
    }
}


struct MeshBackground: View {
    var color1: Color
    var color2: Color
    var color3: Color

    @State private var animatedPoints: [SIMD2<Float>] = [
        SIMD2(0.0, 0.0), SIMD2(0.5, 0.0), SIMD2(1.0, 0.0),
        SIMD2(0.0, 0.5), SIMD2(0.5, 0.5), SIMD2(1.0, 0.5),
        SIMD2(0.0, 1.0), SIMD2(0.5, 1.0), SIMD2(1.0, 1.0)
    ]

    var body: some View {
        ZStack{
        MeshGradient(
            width: 3,
            height: 3,
            points: animatedPoints,
            colors: [
                color1, color2, color3,
                color2, color3, color1,
                color3, color1, color2
            ],
            background: .black,
            smoothsColors: true
        )
        .ignoresSafeArea()
            Rectangle()
                .fill(.ultraThinMaterial)
                .ignoresSafeArea()
                .blur(radius: 10)
    }
        .onAppear {
            animateMesh()
        }
    }

    private func animateMesh() {
        withAnimation(Animation.easeInOut(duration: 8).repeatForever(autoreverses: true)) {
            animatedPoints = animatedPoints.map { point in
                SIMD2(
                    Float(point.x) + Float.random(in: -0.05...0.05),
                    Float(point.y) + Float.random(in: -0.05...0.05)
                )
            }
        }
    }
}
