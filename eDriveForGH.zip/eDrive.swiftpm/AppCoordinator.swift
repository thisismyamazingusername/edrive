//
//  File.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation
import SwiftUI
import ARKit
import RealityKit


class AppCoordinator: ObservableObject {
    @MainActor static let shared = AppCoordinator()

    @Published var navigationPath = NavigationPath()

    func navigate(to view: AppView) {
        navigationPath.append(view)
    }

    func goBackToHome() {
        navigationPath = NavigationPath()
    }
}

enum AppView: Hashable {
    case home
    case tutorial
    case crashCourse
    case testDrive
    case fuelCalc
    case quiz
}
