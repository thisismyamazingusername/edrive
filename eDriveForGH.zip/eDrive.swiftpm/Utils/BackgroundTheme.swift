//
//  BackgroundTheme.swift
//  eDrive Playground
//
//  Created by sd on 2/23/25.
//

import AVFoundation

class AudioManager: ObservableObject {
    var player: AVAudioPlayer?

    func playBackgroundSound() {
        if let url = Bundle.main.url(forResource: "fuel_background", withExtension: "mp3") {
            do {
                player = try AVAudioPlayer(contentsOf: url)
                player?.numberOfLoops = -1 
                player?.play()
            } catch {
                print("Error loading fuel_background.mp3: \(error.localizedDescription)")
            }
        }
    }

    func stopBackgroundSound() {
        player?.stop()
    }
}
