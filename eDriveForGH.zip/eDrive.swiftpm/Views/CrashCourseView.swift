//
//  File.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation
//import SwiftUI
//import RealityKit
//import ARKit
//
//struct CrashCourseView: View {
//    @State private var showMessage = true
//    
//    var body: some View {
//        ZStack {
//            CrashCourseARViewContainer()
//                .edgesIgnoringSafeArea(.all)
//            
//            if showMessage {
//                VStack {
//                    HStack {
//                        Spacer()
//                        Button(action: {
//                            showMessage = false
//                        }) {
//                            Image(systemName: "xmark.circle.fill")
//                                .foregroundColor(.white)
//                                .font(.title)
//                        }
//                        .padding()
//                    }
//                    
//                    Spacer()
//                    
//                    Text("Please turn your device horizontally and turn up the sound. Move your camera around to set the scene!")
//                        .foregroundColor(.white)
//                        .font(.headline)
//                        .multilineTextAlignment(.center)
//                        .padding()
//                        .background(Color.black.opacity(0.7))
//                        .cornerRadius(10)
//                        .padding()
//                    
//                    Spacer()
//                }
//            }
//        }
//    }
//}
//
//#Preview {
//    CrashCourseView()
//}


import SwiftUI
import RealityKit
import ARKit
import AVFoundation

struct CrashCourseView: View {
    @State private var showMessage = true
    private var audioPlayer: AVAudioPlayer?

    init() {
        self.audioPlayer = setupBackgroundAudio()
    }

    var body: some View {
        ZStack {
            CrashCourseARViewContainer()
                .edgesIgnoringSafeArea(.all)
            
            if showMessage {
                VStack {
                    HStack {
                        Spacer()
                        Button(action: {
                            showMessage = false
                        }) {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundColor(.white)
                                .font(.title)
                        }
                        .padding()
                    }
                    
                    Spacer()
                    
                    Text("Please turn your device horizontally and turn up the sound. Move your camera around to set the scene!")
                        .foregroundColor(.white)
                        .font(.headline)
                        .multilineTextAlignment(.center)
                        .padding()
                        .background(Color.black.opacity(0.7))
                        .cornerRadius(10)
                        .padding()
                    
                    Spacer()
                }
            }
        }
        .onAppear {
            audioPlayer?.play()
        }
        .onDisappear {
            audioPlayer?.stop()
        }
    }
    
    private func setupBackgroundAudio() -> AVAudioPlayer? {
        guard let soundURL = Bundle.main.url(forResource: "tap_background", withExtension: "mp3") else {
            print("Background audio file not found")
            return nil
        }
        
        do {
            let player = try AVAudioPlayer(contentsOf: soundURL)
            player.numberOfLoops = -1
            player.volume = 0.05
            return player
        } catch {
            print("Error loading background audio: \(error.localizedDescription)")
            return nil
        }
    }
}

#Preview {
    CrashCourseView()
}
