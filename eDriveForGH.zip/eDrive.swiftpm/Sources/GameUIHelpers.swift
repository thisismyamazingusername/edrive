//
//  GameUIHelpers.swift
//  eDrive Playground
//
//  Created by sd on 2/23/25.
//

import SwiftUI


struct GameUIHelpers {

    static func instructionPopup(closeAction: @escaping () -> Void) -> some View {
        ScrollView{
            VStack(spacing: 20) {
                Text("How to Play")
                    .font(.title)
                    .fontWeight(.bold)
                    .foregroundColor(.black)
                
                VStack(alignment: .leading, spacing: 10) {
                    Text("1. Keep your device vertical and select a gas or electric car.")
                    Text("2. Oops, you're low on fuel!")
                    Text("3. You have 10 seconds to avoid obstacles and refuel*")
                    Text("4. Touch your index finger and thumb, with other fingers closed, to jump over obstacles.")
                    Text("5. Click start!")
                    Text("* Beware of collisions, EVs will need unsustainable battery replacements, whereas gas cars constantly emit carbon emissions especially when idling.")
                }
                .font(.body)
                .padding()
                .foregroundColor(.black)
                
                Button(action: closeAction) {
                    Text("Start")
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                }
            }
            .padding()
            .background(Color.gray)
            .cornerRadius(15)
            .shadow(radius: 10)
        }
    }
    
    static func gameOverPopup(message: String, restart: @escaping () -> Void) -> some View {
        ScrollView {
        VStack {
            Text(message)
                .font(.title)
                .padding()
            Button("Restart") {
                restart()
            }
            .padding()
            .background(Color.red)
            .foregroundColor(.white)
            .clipShape(Capsule())
            }
            .background(Color.white)
            .cornerRadius(10)
            .shadow(radius: 5)
            .padding()
            }
        }

    

    }
