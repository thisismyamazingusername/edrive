//
//  File.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation
import SwiftUI

struct PracticeQuizView: View {
    struct Question {
        let question: String
        let options: [String]
        let correctAnswer: String
        let explanation: String
    }

    let questionBank: [Question] = [
        Question(question: "Which car has zero CO2 emissions?",
                 options: ["Gasoline Car", "Hybrid Car", "Electric Car"],
                 correctAnswer: "Electric Car",
                 explanation: "Electric cars run on batteries and produce no tailpipe emissions."),
        
        Question(question: "When do EVs have a negative impact on the environment?",
                     options: ["Never", "Manufacturing and discarding battery", "Only when manufactured"],
                     correctAnswer: "Manufacturing and discarding battery",
                     explanation: "While EVs produce no emissions during use, their environmental impact comes from manufacturing and improper disposal of batteries. If not recycled properly, EV batteries release toxic chemicals that harm the environment."),
                 
        Question(question: "What is the Air-Fuel Ratio (AFR) for complete combustion in a gasoline engine?",
                 options: ["14.7:1", "12.5:1", "10.0:1"],
                 correctAnswer: "14.7:1",
                 explanation: "An AFR of 14.7:1 means 14.7 parts air to 1 part fuel, ensuring complete combustion with minimal emissions."),
                 
        Question(question: "Which fuel has the highest energy density?",
                 options: ["Diesel", "Hydrogen", "Ethanol"],
                 correctAnswer: "Diesel",
                 explanation: "Diesel fuel contains more energy per gallon than most other fuels, making it highly efficient."),
                 
        Question(question: "Which fuel is most commonly used in aviation due to its high energy density?",
                 options: ["Jet A-1", "Ethanol", "Hydrogen"],
                 correctAnswer: "Jet A-1",
                 explanation: "Jet A-1 is a kerosene-based fuel optimized for aviation due to its high energy content and stability."),
                 
        Question(question: "What does a stoichiometric AFR of 14.7:1 mean?",
                 options: ["14.7 parts air to 1 part fuel", "14.7 parts fuel to 1 part air", "14.7% oxygen in air"],
                 correctAnswer: "14.7 parts air to 1 part fuel",
                 explanation: "This ratio ensures complete combustion with the least amount of excess fuel or air."),
                 
        Question(question: "Which fuel burns the cleanest in terms of CO2 emissions?",
                 options: ["Gasoline", "Diesel", "Hydrogen"],
                 correctAnswer: "Hydrogen",
                 explanation: "Hydrogen fuel only produces water vapor when burned, making it the cleanest option."),
                 
        Question(question: "What is a key advantage of hydrogen fuel?",
                 options: ["Higher CO2 emissions", "Zero emissions", "Lower energy density"],
                 correctAnswer: "Zero emissions",
                 explanation: "Hydrogen fuel produces no CO2, making it an environmentally friendly option."),
                 
        Question(question: "Which engine type is most efficient in converting fuel to energy?",
                 options: ["Gasoline Engine", "Diesel Engine", "Electric Motor"],
                 correctAnswer: "Electric Motor",
                 explanation: "Electric motors convert over 90% of energy into motion, compared to internal combustion engines that waste a lot of energy as heat."),
                 
        Question(question: "Which factor affects fuel combustion efficiency the most?",
                 options: ["Color of the fuel", "Octane rating", "Engine size"],
                 correctAnswer: "Octane rating",
                 explanation: "Higher octane fuel resists premature ignition, improving efficiency and performance."),
                 
        Question(question: "Which type of fuel is considered renewable?",
                 options: ["Ethanol", "Diesel", "Natural Gas"],
                 correctAnswer: "Ethanol",
                 explanation: "Ethanol is made from plant materials like corn and sugarcane, making it a renewable fuel source.")
    ]
    
    @State private var currentQuestions: [Question] = []
    @State private var currentIndex = 0
    @State private var selectedAnswer: String? = nil
    @State private var correctCount = 0
    @State private var showResult = false
    @State private var quizCompleted = false
    @State private var showReview = false

    var body: some View {
        ZStack {
            MeshBackground(color1: .black, color2: .blue, color3: .red)
            VStack {
                if currentQuestions.isEmpty {
                    ProgressView("Loading Quiz...")
                } else if !quizCompleted {
                    Text(currentQuestions[currentIndex].question)
                        .font(.title2)
                        .multilineTextAlignment(.center)
                        .padding()
                        .foregroundColor(.black)
                    
                    
                    ForEach(currentQuestions[currentIndex].options, id: \.self) { option in
                        Button(action: {
                            if selectedAnswer == nil {
                                selectedAnswer = option
                                if option == currentQuestions[currentIndex].correctAnswer {
                                    correctCount += 1
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                                    nextQuestion()
                                }
                            }
                        }) {
                            Text(option)
                                .padding()
                                .frame(minWidth: 300)
                                .foregroundColor(.black)
                                .background(selectedAnswer == option ? (option == currentQuestions[currentIndex].correctAnswer ? Color.green : Color.red) : Color.black.opacity(0.3))
                                .cornerRadius(10)
                        }
                        .disabled(selectedAnswer != nil)
                        .padding(.horizontal)
                    }
                } else {
                    Text("Quiz Completed!")
                        .font(.title)
                        .padding()
                    
                    Text("You got \(correctCount)/5 correct!")
                        .font(.headline)
                        .padding()
                    
                    Button(action: { showReview.toggle() }) {
                        Text("Review Answers")
                            .padding()
                            .background(Color.orange)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding()
                    
                    if showReview {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 10) {
                                ForEach(currentQuestions.indices, id: \.self) { index in
                                    let question = currentQuestions[index]
                                    DisclosureGroup(question.question) {
                                        VStack(alignment: .leading) {
                                            Text("Correct Answer: \(question.correctAnswer)")
                                                .font(.headline)
                                                .foregroundColor(.green)
                                            Text(question.explanation)
                                                .font(.subheadline)
                                                .foregroundColor(.black)
                                                .padding(.top, 2)
                                        }
                                        .padding()
                                        .background(Color.white.opacity(0.8))
                                        .cornerRadius(10)
                                    }
                                    .padding()
                                }
                            }
                            .padding()
                        }
                        .frame(maxHeight: 300)
                    }
                    
                    Button(action: shareResults) {
                        HStack {
                            Image(systemName: "square.and.arrow.up")
                            Text("Share Results")
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                    }
                    .padding()
                    
                    Button(action: startNewQuiz) {
                        Text("Quiz Again")
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                }
            }
        }
        .onAppear {
            startNewQuiz()
        }
    }

    private func nextQuestion() {
        if currentIndex < currentQuestions.count - 1 {
            currentIndex += 1
            selectedAnswer = nil
        } else {
            quizCompleted = true
        }
    }

    private func startNewQuiz() {
        currentQuestions = Array(questionBank.shuffled().prefix(5))
        currentIndex = 0
        selectedAnswer = nil
        correctCount = 0
        quizCompleted = false
    }

    private func shareResults() {
        let message = "I scored \(correctCount)/5 on my eDrive quiz! Can you beat my score??"
        let activityVC = UIActivityViewController(activityItems: [message], applicationActivities: nil)

        if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
           let rootViewController = windowScene.windows.first?.rootViewController {
            
            if let popoverController = activityVC.popoverPresentationController {
                popoverController.sourceView = rootViewController.view
                popoverController.sourceRect = CGRect(x: rootViewController.view.bounds.midX,
                                                      y: rootViewController.view.bounds.midY,
                                                      width: 0,
                                                      height: 0)
                popoverController.permittedArrowDirections = []
            }
            
            rootViewController.present(activityVC, animated: true, completion: nil)
        }
    }


}
