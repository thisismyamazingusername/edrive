//  File.swift
//  eDrive
//
//  Created by sd on 2/13/25.
//

import Foundation
import SwiftUI

struct FuelInfoPopup: View {
    @Binding var isPresented: Bool
    
    var body: some View {
        if isPresented {
            VStack(alignment: .leading, spacing: 10) {
                Text("Fuel Properties")
                    .font(.title2)
                    .bold()
                    .foregroundColor(.black)
                    .padding(.bottom, 5)
                ScrollView {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("❓If we understand that hybrid, EV, and gas cars each have different sustainability profiles based on their fuel sources, why aren't we using only the most sustainable fuels, like solar, in all vehicles?")
                            .bold()
                            .padding()
                        
                        Text("While gasoline and electricity are the most common fuel sources, many others exist, including biodiesel, hydrogen, ethanol, propane, sustainable aviation fuel, and various emerging fuels. Thus, not any substance can be used as fuel, which is what our fuel calculator helps to understand. To get started with the fuel calculator, simply adjust the number of Carbon, Hydrogen, and Oxygen atoms in the substance you want to test.").padding(.horizontal, 10)
                        
                        Text("✏️ To determine if a substance can be a suitable and sustainable fuel for vehicles, we need to consider several key factors:")
                            .bold()
                            .padding()
                        
                        Group {
                            Text("1. Energy Density (MJ/kg or MJ/L)").bold()
                            Text("• How much energy a fuel can release per unit mass or volume.")
                            Text("• Higher energy density means more energy is stored in a smaller amount of fuel, making it more efficient for transportation and storage.")
                            Text("• Lower energy density fuels require larger volumes or heavier masses to provide the same energy output.").padding(.vertical, 10)
                            
                            Text("2. Stoichiometric Air-Fuel Ratio (AFR)").bold()
                            Text("• Can be calculated from C, H, and O using the formula:")
                            Text("   AFR = (32C + 4H - 16O) / (4.76 × (12C + H + 16O))")
                            Text("• If O is too high, the denominator can be zero or negative, meaning the fuel is not combustible.") .padding(.vertical, 10)
                            
                            Text("3. Combustibility").bold()
                            Text("• If AFR is reasonable and balanced, the fuel is likely combustible.")
                            Text("• Too much or too little oxygen can hinder combustion.") .padding(.vertical, 10)
                            
                            Text("4. Chemical Stability").bold()
                            Text("• More oxygen → Less stable.")
                            Text("• Strucutrally, highly branched hydrocarbons → More stable compared to linear.")
                            Text("• Aromatics → Very stable.")
                            Text("• Small molecules like Methanol and Ethanol → Volatile but stable.") .padding(.vertical, 10)
                            
                            Text("5. Sustainability Factors").bold()
                            Text("• Bio-derived fuels like Ethanol and Biodiesel → More sustainable.")
                            Text("• Hydrocarbon-based fuels like Octane and Diesel → Fossil-based, limited and less sustainable.")
                            Text("• Hydrogen → Very clean but requires sustainable production.") .padding(.vertical, 10)
                        }.padding(.horizontal, 10)
                        
                        HStack {
                            Spacer()
                            Button("Try Calculator") {
                                isPresented = false
                            }
                            .padding()
                            .frame(maxWidth: 200)
                            .background(Color.red.opacity(0.6))
                            .cornerRadius(10)
                            Spacer()
                        }.padding(.vertical, 10)
                    }
                        .foregroundColor(.black)
                    }
                    .frame(maxHeight: UIScreen.main.bounds.height * 0.8)
                }
                .padding()
                .background(Color.white)
                .cornerRadius(15)
                .shadow(radius: 10)
                .frame(minWidth: UIScreen.main.bounds.width * 0.8, minHeight: UIScreen.main.bounds.height * 0.8)
                .overlay(alignment: .topTrailing) {
                    Button(action: { isPresented = false }) {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(.gray)
                            .padding(10)
                    }
                }
            }
        }
    }
